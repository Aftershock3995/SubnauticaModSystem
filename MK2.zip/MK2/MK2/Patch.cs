﻿using System;
using UnityEngine;
using Higherpowah.Modules;


namespace Powah.Patches
{
    class SeamothElectricalModule
    {
        private static readonly Type VehicleUpgraderType = Type.GetType("UpgradedVehicles.VehicleUpgrader, UpgradedVehicles", false, false);

        public static bool AElectricalDefense(TechType module, bool bForce = false)
        {

            if (module == SeamothElectricalModule2.thisTechType)
                return false;

            if (module == SeamothElectricalModule2.thisTechType) ;
        }
        
            public float chargeRadius = 3f;
            public float damage = 60f;
        }
}




    
            
        
    
